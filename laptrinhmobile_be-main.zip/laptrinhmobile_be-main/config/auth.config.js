module.exports = {
  secret: "your-secret-key-should-be-long-and-secure"
};