/**
 * @swagger
 * components:
 *   schemas:
 *     User:
 *       type: object
 *       required:
 *         - username
 *         - email
 *         - password
 *       properties:
 *         id:
 *           type: integer
 *           description: The auto-generated id of the user
 *         username:
 *           type: string
 *           description: The username
 *         email:
 *           type: string
 *           description: The user email
 *         password:
 *           type: string
 *           description: The user password
 *       example:
 *         username: johndoe
 *         email: john@example.com
 *         password: password123
 *   securitySchemes:
 *     bearerAuth:
 *       type: http
 *       scheme: bearer
 *       bearerFormat: JWT
 */

/**
 * @swagger
 * tags:
 *   name: Users
 *   description: User API
 */

module.exports = app => {
  const users = require("../controllers/user.controller.js");
  const { verifyToken } = require("../middleware/auth.jwt.js");

  /**
   * @swagger
   * /api/users:
   *   post:
   *     summary: Create a new user
   *     tags: [Users]
   *     security:
   *       - bearerAuth: []
   *     requestBody:
   *       required: true
   *       content:
   *         application/json:
   *           schema:
   *             $ref: '#/components/schemas/User'
   *     responses:
   *       200:
   *         description: The user was successfully created
   *         content:
   *           application/json:
   *             schema:
   *               $ref: '#/components/schemas/User'
   *       401:
   *         description: Unauthorized
   *       403:
   *         description: No token provided
   *       500:
   *         description: Some server error
   */
  app.post("/api/users", verifyToken, users.create);

  /**
   * @swagger
   * /api/users:
   *   get:
   *     summary: Returns the list of all users
   *     tags: [Users]
   *     security:
   *       - bearerAuth: []
   *     responses:
   *       200:
   *         description: The list of users
   *         content:
   *           application/json:
   *             schema:
   *               type: array
   *               items:
   *                 $ref: '#/components/schemas/User'
   *       401:
   *         description: Unauthorized
   *       403:
   *         description: No token provided
   */
  app.get("/api/users", verifyToken, users.findAll);

  /**
   * @swagger
   * /api/users/{userId}:
   *   get:
   *     summary: Get a user by id
   *     tags: [Users]
   *     security:
   *       - bearerAuth: []
   *     parameters:
   *       - in: path
   *         name: userId
   *         schema:
   *           type: integer
   *         required: true
   *         description: The user id
   *     responses:
   *       200:
   *         description: The user description by id
   *         content:
   *           application/json:
   *             schema:
   *               $ref: '#/components/schemas/User'
   *       401:
   *         description: Unauthorized
   *       403:
   *         description: No token provided
   *       404:
   *         description: The user was not found
   */
  app.get("/api/users/:userId", verifyToken, users.findOne);

  /**
   * @swagger
   * /api/users/{userId}:
   *   put:
   *     summary: Update a user by id
   *     tags: [Users]
   *     security:
   *       - bearerAuth: []
   *     parameters:
   *       - in: path
   *         name: userId
   *         schema:
   *           type: integer
   *         required: true
   *         description: The user id
   *     requestBody:
   *       required: true
   *       content:
   *         application/json:
   *           schema:
   *             $ref: '#/components/schemas/User'
   *     responses:
   *       200:
   *         description: The user was updated
   *         content:
   *           application/json:
   *             schema:
   *               $ref: '#/components/schemas/User'
   *       401:
   *         description: Unauthorized
   *       403:
   *         description: No token provided
   *       404:
   *         description: The user was not found
   *       500:
   *         description: Some error happened
   */
  app.put("/api/users/:userId", verifyToken, users.update);

  /**
   * @swagger
   * /api/users/{userId}:
   *   delete:
   *     summary: Remove a user by id
   *     tags: [Users]
   *     security:
   *       - bearerAuth: []
   *     parameters:
   *       - in: path
   *         name: userId
   *         schema:
   *           type: integer
   *         required: true
   *         description: The user id
   *     responses:
   *       200:
   *         description: The user was deleted
   *       401:
   *         description: Unauthorized
   *       403:
   *         description: No token provided
   *       404:
   *         description: The user was not found
   */
  app.delete("/api/users/:userId", verifyToken, users.delete);
};