const sql = require('../config/db.js');
const bcrypt = require('bcryptjs');

// User constructor
const User = function(user) {
  this.username = user.username;
  this.email = user.email;
  this.password = user.password;
};

// Register a new User
User.register = async (newUser, result) => {
  try {
    // Hash the password
    const salt = await bcrypt.genSalt(10);
    newUser.password = await bcrypt.hash(newUser.password, salt);
    
    // Check if username or email already exists
    sql.query(
      "SELECT * FROM user WHERE username = ? OR email = ?", 
      [newUser.username, newUser.email], 
      (err, res) => {
        if (err) {
          console.log("error: ", err);
          result(err, null);
          return;
        }
        
        if (res.length > 0) {
          // Check which field is duplicate
          if (res.some(user => user.username === newUser.username)) {
            result({ kind: "duplicate_username" }, null);
            return;
          }
          if (res.some(user => user.email === newUser.email)) {
            result({ kind: "duplicate_email" }, null);
            return;
          }
        }
        
        // Insert new user
        sql.query("INSERT INTO user SET ?", newUser, (err, res) => {
          if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
          }
          
          // Don't return password in response
          const { password: userPassword, ...userWithoutPassword } = newUser;
          console.log("registered user: ", { id: res.insertId, ...userWithoutPassword });
          result(null, { id: res.insertId, ...userWithoutPassword });
        });
      }
    );
  } catch (error) {
    console.log("error: ", error);
    result(error, null);
  }
};

// Login User
User.login = (username, password, result) => {
  sql.query(
    "SELECT * FROM user WHERE username = ?", 
    [username], 
    async (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(err, null);
        return;
      }
      
      if (res.length === 0) {
        // User not found
        result({ kind: "invalid_credentials" }, null);
        return;
      }
      
      const user = res[0];
      
      // Compare password
      try {
        const isMatch = await bcrypt.compare(password, user.password);
        
        if (!isMatch) {
          result({ kind: "invalid_credentials" }, null);
          return;
        }
        
        // Don't return password in response
        const { password: userPassword, ...userWithoutPassword } = user;
        result(null, userWithoutPassword);
      } catch (error) {
        console.log("error: ", error);
        result(error, null);
      }
    }
  );
};

// Create a new User (original method kept for compatibility)
User.create = (newUser, result) => {
  sql.query("INSERT INTO user SET ?", newUser, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    console.log("created user: ", { id: res.insertId, ...newUser });
    result(null, { id: res.insertId, ...newUser });
  });
};

// Find a User by ID
User.findById = (userId, result) => {
  sql.query(`SELECT id, username, email FROM user WHERE id = ${userId}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.length) {
      console.log("found user: ", res[0]);
      result(null, res[0]);
      return;
    }

    // User with the id not found
    result({ kind: "not_found" }, null);
  });
};

// Get all Users
User.getAll = result => {
  sql.query("SELECT id, username, email FROM user", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log("users: ", res);
    result(null, res);
  });
};

// Update a User by ID
User.updateById = (id, user, result) => {
  // Check if password is being updated
  if (user.password) {
    bcrypt.genSalt(10, (err, salt) => {
      if (err) {
        console.log("error: ", err);
        result(err, null);
        return;
      }
      
      bcrypt.hash(user.password, salt, (err, hash) => {
        if (err) {
          console.log("error: ", err);
          result(err, null);
          return;
        }
        
        user.password = hash;
        updateUser(id, user, result);
      });
    });
  } else {
    updateUser(id, user, result);
  }
};

// Helper function for updating user
function updateUser(id, user, result) {
  sql.query(
    "UPDATE user SET username = ?, email = ?, password = ? WHERE id = ?",
    [user.username, user.email, user.password, id],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }

      if (res.affectedRows == 0) {
        // User not found
        result({ kind: "not_found" }, null);
        return;
      }

      // Don't return password in response
      const { password: userPassword, ...userWithoutPassword } = user;
      console.log("updated user: ", { id: id, ...userWithoutPassword });
      result(null, { id: id, ...userWithoutPassword });
    }
  );
}

// Delete a User by ID
User.remove = (id, result) => {
  sql.query("DELETE FROM user WHERE id = ?", id, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // User not found
      result({ kind: "not_found" }, null);
      return;
    }

    console.log("deleted user with id: ", id);
    result(null, res);
  });
};

module.exports = User;