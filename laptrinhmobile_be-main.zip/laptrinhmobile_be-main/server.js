const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const { swaggerUi, swaggerDocs } = require('./config/swagger');

const app = express();

// Enable CORS for all routes
app.use(cors());

// Parse requests of content-type: application/json
app.use(bodyParser.json());

// Parse requests of content-type: application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

// Setup Swagger
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocs));

// Simple route
app.get("/", (req, res) => {
  res.json({ 
    message: "Welcome to the user API.",
    documentation: "Visit /api-docs for interactive API documentation"
  });
});

// Include routes
require("./routes/auth.routes.js")(app);
require("./routes/user.routes.js")(app);

// Set port and start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
  console.log(`Swagger documentation available at http://localhost:${PORT}/api-docs`);
});